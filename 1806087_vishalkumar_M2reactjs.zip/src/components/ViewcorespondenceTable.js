import React from 'react';
import Paper from '@material-ui/core/Paper';
import Buttons from '../components/Buttons';
import Table from '../components/Table'
import TableHead from '@material-ui/core/TableHead';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import { makeStyles } from '@material-ui/core/styles';
import { Checkbox } from '@material-ui/core';

const useStyles = makeStyles({
  tablecell: {
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif",
    color: '#whitesmoke',
    borderBottom: "none",
    padding: "10px"
  },
  
});

export default function GriViewcorespondenceTabledComp() {
  const classes = useStyles();
  return (
    
      
      
        <TableHead>
          <TableRow>
            
            <TableCell width="5%" className={classes.tablecell} align='left'>Number</TableCell>
            <TableCell width="5%" className={classes.tablecell} align="left">PO Num</TableCell>
            <TableCell width="1%" className={classes.tablecell} align="left">Inv_Date</TableCell>
            <TableCell width="5%" className={classes.tablecell} align="left">Due Date</TableCell>
            <TableCell width="5%" className={classes.tablecell} align="right">Company</TableCell>
            <TableCell width="5%" className={classes.tablecell} align="left"> Amount</TableCell>
            
          </TableRow>
          <TableRow>
          <TableCell width="12%" className={classes.tablecell} align="left">123456</TableCell>
              <TableCell width="10%" className={classes.tablecell} align="left">12345</TableCell>
              <TableCell width="12%" className={classes.tablecell} align="left">23 jan21</TableCell>
              <TableCell width="12%" className={classes.tablecell} align="center">02 jan21</TableCell>
              <TableCell width="15%" className={classes.tablecell} align="center">USD</TableCell>
              <TableCell width="8%" className={classes.tablecell} align="right">
                122.5K  
           </TableCell>


          </TableRow>
          <TableRow>

          <TableCell width="12%" className={classes.tablecell} align="left">123456</TableCell>
              <TableCell width="10%" className={classes.tablecell} align="left">12345</TableCell>
              <TableCell width="12%" className={classes.tablecell} align="left">20 jan21</TableCell>
              <TableCell width="12%" className={classes.tablecell} align="center">15 jan21</TableCell>
              <TableCell width="15%" className={classes.tablecell} align="center">USD</TableCell>
              <TableCell width="8%" className={classes.tablecell} align="right">
                1.45K 
           </TableCell>
          </TableRow>
        </TableHead>
        
    
    
    
       
    
  );
}
