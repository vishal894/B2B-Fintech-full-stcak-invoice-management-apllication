import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import { TextField } from '@material-ui/core';
import Box from '@material-ui/core/Box';
import EditIcon from '@material-ui/icons/Edit';
import SearchIcon from '@material-ui/icons/Search';
import IconButton from "@material-ui/core/IconButton";
import RemoveIcon from '@material-ui/icons/Remove';
import AddDialog from '../components/AddDialog';
import DeleteButton from '../components/DeleteButton';
import EditButton from '../components/EditButton';
import AddButton from '../components/AddButton';
import SearchComponent from '../components/SearchComponent';

import DelDialog from '../components/DelDialog';
import Add from '../components/Add.js';
import PredictButton from '../components/PredictButton';

import ViewCorrespondance from '../components/ViewCorrespondance';

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
      padding: "2px"
    },
    labelRoot: {
      fontSize: 30,
      color: "white",
      "&.labelFocused": {
        color: "black",
       // textAlign: "center"
      }
    },
    labelFocused: {}
  },
  col:{
    margin: theme.spacing(1)
  }
}));

export default function Buttons() {
  const classes = useStyles();

  return (
    <div style={{width:'100%'}}className={classes.root}>
      <Box display='flex' p={0}>
      <Box p={1}>
        <PredictButton/>
      </Box>
      <Box p={1} flexGrow={1}>
      < ViewCorrespondance  />
      </Box>
      <Box p={1}>
        {/* You can use <AddButton/> also to showcase table in proper format */}
         {/* You can use <AddDialog/> use to fetch data from database */}
        <AddDialog />
      </Box>
      <Box p={1} className={classes.col}>
         <EditButton />
      </Box>
      <Box p={1} >
           <DelDialog />
      </Box>
      <Box p={1}>
         <SearchComponent/>
      </Box>
      </Box>
    </div>
  );
}
