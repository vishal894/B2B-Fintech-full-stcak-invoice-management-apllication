import React from 'react';

function GridHeader() {
  return (
      <div id='gridheader'>
          Invoice List
      </div>
  )
}

export default GridHeader;